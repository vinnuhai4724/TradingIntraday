# Intraday Stock Signal Generator

This is a Java-based intraday stock signal generator that provides stock picks and sends them to a Telegram bot.

## Prerequisites
- Java 17+
- Fly.io CLI for deployment
